"use client";
import React, { useState, useEffect, useContext } from "react";
import { db } from "@/components/firebase"; // Import the db object
import { AppContext } from "@/context/appContext";
import { useRouter } from "next/navigation";

function MyComponent() {
  const router = useRouter();
  const { auth, setAuth } = useContext(AppContext);
  const [data, setData] = useState({});

  useEffect(() => {
    const ref = db.ref("users"); // your Realtime Database reference

    ref.on("value", (snapshot) => {
      const collectorData = {};
      Object.keys(snapshot.val()).forEach((key) => {
        if (snapshot.val()[key].userType === "collector") {
          collectorData[key] = snapshot.val()[key];
        }
      });
      setData(collectorData);
    });

    return () => ref.off(); // Clean up listener on component unmount
  }, []);

  useEffect(() => {
    if (auth === false) {
      router.push("/login");
    }
  }, [auth]);

  useEffect(() => {
    console.log(data);
  }, [data]);

  if (auth === null || auth === false) {
    return null;
  }

  if (auth) {
    return (
      <React.Fragment>
        <nav className="navbar navbar-expand-lg bg-body-tertiary">
          <div className="container">
            <a className="navbar-brand" href="#">
              Navbar
            </a>
            <button
              className="navbar-toggler"
              type="button"
              data-bs-toggle="collapse"
              data-bs-target="#navbarNavDropdown"
              aria-controls="navbarNavDropdown"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <span className="navbar-toggler-icon"></span>
            </button>
            <div className="collapse navbar-collapse" id="navbarNavDropdown">
              <ul className="navbar-nav ms-auto">
                <li className="nav-item dropdown">
                  <a
                    className="nav-link dropdown-toggle"
                    href="#"
                    role="button"
                    data-bs-toggle="dropdown"
                    aria-expanded="false"
                  >
                    Profile
                  </a>
                  <ul className="dropdown-menu dropdown-menu-end">
                    <li>
                      <a className="dropdown-item" href="#">
                        Sttings
                      </a>
                    </li>
                    <li>
                      <a className="dropdown-item" href="#">
                        Logout
                      </a>
                    </li>
                  </ul>
                </li>
              </ul>
            </div>
          </div>
        </nav>
        <div className="container">
          {/* <p>logged in</p> */}
          <ul className="nav nav-tabs mt-5" id="myTab" role="tablist">
            <li className="nav-item" role="presentation">
              <button
                className="nav-link active"
                id="User-tab"
                data-bs-toggle="tab"
                data-bs-target="#User-tab-pane"
                type="button"
                role="tab"
                aria-controls="User-tab-pane"
                aria-selected="true"
              >
                User
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className="nav-link"
                id="profile-tab"
                data-bs-toggle="tab"
                data-bs-target="#profile-tab-pane"
                type="button"
                role="tab"
                aria-controls="profile-tab-pane"
                aria-selected="false"
              >
                Profile
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className="nav-link"
                id="contact-tab"
                data-bs-toggle="tab"
                data-bs-target="#contact-tab-pane"
                type="button"
                role="tab"
                aria-controls="contact-tab-pane"
                aria-selected="false"
              >
                Contact
              </button>
            </li>
            <li className="nav-item" role="presentation">
              <button
                className="nav-link"
                id="disabled-tab"
                data-bs-toggle="tab"
                data-bs-target="#disabled-tab-pane"
                type="button"
                role="tab"
                aria-controls="disabled-tab-pane"
                aria-selected="false"
                disabled
              >
                Disabled
              </button>
            </li>
          </ul>

          <div
            className="tab-content card card-body"
            style={{
              borderTopLeftRadius: "0px",
              borderTop: "0px",
              borderTopRightRadius: "0px",
            }}
            id="myTabContent"
          >
            <div
              className="tab-pane fade show active"
              id="User-tab-pane"
              role="tabpanel"
              aria-labelledby="User-tab"
              tabIndex="0"
            >
              <div className="row g-4">
                {data && (
                  <React.Fragment>
                    {Object.values(data).map((user) => (
                      <div className="col-md-4" key={user.uId}>
                        <div className="card card-body">
                          <div className="d-flex flex-row align-items-center mb-4">
                            <div
                              style={{
                                display: "block",
                                width: "50px",
                                height: "50px",
                                background: "lightgrey",
                                borderRadius: "50px",
                              }}
                            ></div>
                            <div className="d-flex flex-column ms-3">
                              <h5 className="mb-0">{user.userName}</h5>
                              <small className="text-muted">
                                {user.userEmail}
                              </small>
                            </div>
                          </div>
                          <div className="d-flex flex-row align-items-center">
                            <select
                              className="form-select me-3"
                              aria-label="Default select example"
                            >
                              <option defaultValue hidden>
                                Assign Bin to this person
                              </option>
                              <option value="1">One</option>
                              <option value="2">Two</option>
                              <option value="3">Three</option>
                              <option value="4">Four</option>
                              <option value="5">Five</option>
                              <option value="6">Six</option>
                            </select>
                            {user.userType}
                          </div>
                        </div>
                      </div>
                    ))}
                  </React.Fragment>
                )}
              </div>
            </div>
            <div
              className="tab-pane fade"
              id="profile-tab-pane"
              role="tabpanel"
              aria-labelledby="profile-tab"
              tabIndex="0"
            >
              <div className="row">
                <div className="col-md-6">
                  <div
                    className="progress"
                    role="progressbar"
                    aria-label="Example 20px high"
                    aria-valuenow="25"
                    aria-valuemin="0"
                    aria-valuemax="100"
                    style={{ height: "20px" }}
                  >
                    <div
                      className="progress-bar"
                      style={{ width: "25%" }}
                    ></div>
                  </div>
                </div>
              </div>
            </div>
            <div
              className="tab-pane fade"
              id="contact-tab-pane"
              role="tabpanel"
              aria-labelledby="contact-tab"
              tabIndex="0"
            >
              ...
            </div>
            <div
              className="tab-pane fade"
              id="disabled-tab-pane"
              role="tabpanel"
              aria-labelledby="disabled-tab"
              tabIndex="0"
            >
              ...
            </div>
          </div>
        </div>
      </React.Fragment>
    );
  }
}

export default MyComponent;
